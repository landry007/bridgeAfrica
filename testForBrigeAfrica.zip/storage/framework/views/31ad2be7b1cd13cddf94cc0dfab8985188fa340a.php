<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Update Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container">
        <img class="m-3" height="250" width="250" src="<?php echo e($product->image_url); ?>">

        <form method="post" action="<?php echo e(route('product.update', $product->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Product Name</label>
                <input name="name" type="text" value="<?php echo e($product->name); ?>" class="form-control" id="name"
                       aria-describedby="emailHelp"
                       placeholder="Product Name">
            </div>
            <div class="form-group">
                <label for="nature">Nature of product</label>
                <select name="nature" class="form-control" id="nature">
                    <option>Bien</option>
                    <option>Service</option>
                </select>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control" id="price"
                       placeholder="Price">
            </div>
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="number" name="quantity" value="<?php echo e($product->quantity); ?>" class="form-control" id="quantity"
                       placeholder="Price">
            </div>

            <div class="form-group">
                <label for="categoryId">Product Category</label>
                <select name="category" class="form-control" id="categoryId">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php if(  $category->id == $product->id ): ?>
                            <option value="<?php echo e($category->id); ?>" selected><?php echo e($product->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="validity">Validity</label>
                <input type="datetime-local" value="<?php echo e($product->validity); ?>" class="form-control" name="validity"
                       id="validity" placeholder="Validity">
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\test\testForBrigeAfrica\resources\views/products/update.blade.php ENDPATH**/ ?>