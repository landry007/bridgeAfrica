<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">

            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>

            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 ml-4 mb-3 mt-2" style="margin-right: 5rem;">
                    <div class="card " style="width: 18rem;">
                        <img style="height: 10em;" src="<?php echo e($product->image_url); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?>

                                <?php if($product->trashed()): ?>
                                <span class="badge
                                badge-danger">Is deleted</span>
                                <?php endif; ?>
                            </h5>
                            <p class="card-text"> Price <?php echo e($product->price); ?> </p>
                            <p class="card-text"> Quantity <?php echo e($product->quantity); ?> </p>
                            <a href="<?php echo e(route('product.show', $product->id)); ?>" class="btn btn-primary">View
                                Detail</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-dark" role="alert">
                    <h1>No Products in Store, Please create a product. <a class="nav-link" href="<?php echo e(route
                        ('product.create')); ?>">Create product</a></h1>
                </div>
                <?php endif; ?>
            </div>
            <div class=" m-3">
                <?php echo e($products->links()); ?>


            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\test\testForBrigeAfrica\resources\views/products/product.blade.php ENDPATH**/ ?>