<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e($product->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <img class="m-3" height="150" width="250" src="<?php echo e($product->image_url); ?>">

            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-7">
                            <h4> <?php echo e($product->name); ?></h4>
                        </div>
                        <div class="col-md-4">
                            Last updated <?php echo e($product->updated_at); ?>

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Nature
                            <span class="badge badge-primary badge-pill"> <?php echo e($product->nature); ?> </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Category
                            <span class="badge badge-primary badge-pill"> <?php echo e($product->category->name); ?> </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Quantity
                            <span class="badge badge-primary badge-pill"> <?php echo e($product->quantity); ?> </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Price
                            <span class="badge badge-primary badge-pill"><?php echo e($product->price); ?> CFA</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Validity
                            <span class="badge badge-primary badge-pill"><?php echo e($product->validity); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Created at
                            <span class="badge badge-primary badge-pill"><?php echo e($product->created_at); ?></span>
                        </li>
                        <?php if($product->trashed()): ?>
                        <li class="list-group-item list-group-item-danger  d-flex justify-content-between
                            align-items-center">
                            deleted_at
                            <span class="badge badge-primary badge-pill"><?php echo e($product->deleted_at); ?></span>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card-footer">


                    <div class="row">
                        <?php if(!$product->trashed()): ?>

                        <div class="col-md-7">
                            <form method="get" action="<?php echo e(route('product.edit', $product->id )); ?>">
                                <?php echo method_field('GET'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-secondary mr-4">Update</button>
                            </form>
                        </div>
                        <?php endif; ?>
                        <?php if(!$product->trashed()): ?>

                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('product.delete', $product->id )); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                        <?php endif; ?>

                        <?php if($product->trashed()): ?>

                        <div class="col-md-4">
                            <a href="<?php echo e(route('product.restore', $product->id )); ?>" class="btn btn-primary btn-lg
                                active" role="button" aria-pressed="true">Restore product</a>

                        </div>
                        <?php endif; ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\test\testForBrigeAfrica\resources\views/products/show.blade.php ENDPATH**/ ?>